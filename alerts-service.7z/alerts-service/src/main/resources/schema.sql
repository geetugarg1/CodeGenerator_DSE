create table tableOfSchemas

(

   schemaId long not null,

   name varchar(255) not null,

   description varchar(255),
   
   source varchar(255),

   primary key(schemaId)

);
create table tableOfClassificationClassified

(

   valueId varchar(255) not null,

   classifiedByValueId varchar(255) not null,
   
   status varchar(255),
   
   primary key(valueId)

);

create table tableOfClassificationValues

(

   custId long not null,

   valueId varchar(255) not null,

   
   foreign key (valueId) references tableOfClassificationClassified(valueId)

);



create table tableOfClassificationValueTypes

(

   valueId varchar(255) not null,
   
   name varchar(255) not null,
   
   status varchar(255),

   schemaId long not null,
   
   description varchar(255),
   
   primary key(valueId),
   foreign key (schemaId) references tableOfSchemas(schemaId)

);
