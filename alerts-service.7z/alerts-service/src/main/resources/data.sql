insert into tableOfSchemas values(2,'Alerts', '', 'Internal');
insert into tableOfSchemas values(1,'Alerts Criticity', '', 'Internal');




insert into tableOfClassificationClassified values('00001','00006','Active');
insert into tableOfClassificationClassified values('00002','00006','Active');
insert into tableOfClassificationClassified values('00003','00006','Active');
insert into tableOfClassificationClassified values('00004','00007','Active');
insert into tableOfClassificationClassified values('00005','00007','Active');

insert into tableOfClassificationValues values(12345,'00001');
insert into tableOfClassificationValues values(12345,'00002');
insert into tableOfClassificationValues values(12345,'00003');
insert into tableOfClassificationValues values(12345,'00004');
insert into tableOfClassificationValues values(54321,'00005');



insert into tableOfClassificationValueTypes values('00001','Encrypted account','Active',1,'');
insert into tableOfClassificationValueTypes values('00002','The account has wrong adddress','Active',1,'');
insert into tableOfClassificationValueTypes values('00003','Alert 1 type 2','Active',1,'');
insert into tableOfClassificationValueTypes values('00004','Alert 2 type 2','Active',1,'');
insert into tableOfClassificationValueTypes values('00005','Alert 3 type 2','Active',1,'');
insert into tableOfClassificationValueTypes values('00006','Type 1 Alert','Active',2,'');
insert into tableOfClassificationValueTypes values('00007','Type 2 alert','Active',2,'');










