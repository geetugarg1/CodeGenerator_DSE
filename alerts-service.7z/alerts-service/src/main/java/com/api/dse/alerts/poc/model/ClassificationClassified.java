package com.api.dse.alerts.poc.model;

public class ClassificationClassified {

	private String valueId;
	private String classifiedByValueId;
	private String status;

	public ClassificationClassified() {
	}

	public ClassificationClassified(String valueId, String classifiedByValueId, String status) {
		this.valueId = valueId;
		this.classifiedByValueId = classifiedByValueId;
		this.status = status;
	}

	public String getValueId() {
		return valueId;
	}

	public void setValueId(String valueId) {
		this.valueId = valueId;
	}

	public String getClassifiedByValueId() {
		return classifiedByValueId;
	}

	public void setClassifiedByValueId(String classifiedByValueId) {
		this.classifiedByValueId = classifiedByValueId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
