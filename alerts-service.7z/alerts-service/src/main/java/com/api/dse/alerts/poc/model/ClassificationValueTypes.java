package com.api.dse.alerts.poc.model;

public class ClassificationValueTypes {

	private String valueId;
	private String name;
	private String status;
	private Long schemaId;
	private String description;

	public ClassificationValueTypes() {
	}

	public ClassificationValueTypes(String valueId, String name, String status, Long schemaId, String description) {
		this.valueId = valueId;
		this.name = name;
		this.status = status;
		this.schemaId = schemaId;
		this.description = description;
	}

	public String getValueId() {
		return valueId;
	}

	public void setValueId(String valueId) {
		this.valueId = valueId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getSchemaId() {
		return schemaId;
	}

	public void setSchemaId(Long schemaId) {
		this.schemaId = schemaId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
