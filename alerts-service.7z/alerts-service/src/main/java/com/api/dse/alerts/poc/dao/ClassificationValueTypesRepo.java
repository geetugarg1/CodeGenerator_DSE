package com.api.dse.alerts.poc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.api.dse.alerts.poc.model.ClassificationValueTypes;
import com.api.dse.alerts.poc.model.Schemas;

@Repository
public class ClassificationValueTypesRepo {

	 @Autowired
	 JdbcTemplate template;
	 
	public ClassificationValueTypesRepo() {
		// TODO Auto-generated constructor stub
	}
	
	public List<ClassificationValueTypes> findBySchemaId(Long schemaId) {

	    return template.query("select * from tableOfClassificationValueTypes where schemaId=?", new Object[] {

	    		schemaId

	        },

	        new BeanPropertyRowMapper < ClassificationValueTypes > (ClassificationValueTypes.class));

	}
	
	public ClassificationValueTypes findByValueId(String valueId) {

	    return template.queryForObject("select * from tableOfClassificationValueTypes where valueId=?", new Object[] {

	    		valueId

	        },

	        new BeanPropertyRowMapper < ClassificationValueTypes > (ClassificationValueTypes.class));

	}

}
