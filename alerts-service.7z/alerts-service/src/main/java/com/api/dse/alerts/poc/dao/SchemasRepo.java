package com.api.dse.alerts.poc.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.api.dse.alerts.poc.model.Schemas;

@Repository
public class SchemasRepo {
	
	 @Autowired
	 JdbcTemplate template;

	public SchemasRepo() {
		// TODO Auto-generated constructor stub
	}
	
	public Schemas findByName(String name) {

	    return template.queryForObject("select * from tableOfSchemas where name=?", new Object[] {

	            name

	        },

	        new BeanPropertyRowMapper < Schemas > (Schemas.class));

	}

}
