package com.api.dse.alerts.poc.services.impl;

import java.util.*;

import com.api.dse.alerts.poc.model.*;

import com.api.dse.alerts.poc.dao.*;
import com.api.dse.alerts.poc.services.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class AlertsImpl implements AlertsI {
	@Autowired
	SchemasRepo schemasRepo;
	@Autowired
	ClassificationValueTypesRepo classificationValueTypesRepo;
	@Autowired
	ClassificationValuesRepo classificationValuesRepo;
	@Autowired
	ClassificationClassifiedRepo classificationClassifiedRepo;

	@Override
	@HystrixCommand(fallbackMethod = "reliable")
	public AlertsResponseWrapper execute(AlertsP pojo) {
		// TODO
		long customerid = pojo.getCustomerid();
		Schemas schobj = schemasRepo.findByName("Alerts");
		// will return 1 to 4
		List<ClassificationValues> classificationValuesList = classificationValuesRepo
				.findByCustId(pojo.getCustomerid(), schobj.getSchemaId());
		System.out.println("AlertsImpl.execute()" + classificationValuesList.get(0).getValueId() + "size>>"
				+ classificationValuesList.size());
		// wil return 6 & 7
		List<ClassificationClassified> classificationClassifiedList = classificationClassifiedRepo
				.findBySchemaId(schobj.getSchemaId());
		System.out.println("AlertsImpl.execute()" + classificationClassifiedList.get(0).getClassifiedByValueId());
		// for each classificationClassifiedList, get type of alert and put in map
		Map<String, String> valueIdAlertTypeMap = new HashMap<>();
		for (ClassificationClassified classificationClassifiedObj : classificationClassifiedList) {
			ClassificationValueTypes classificationValueTypesObj = classificationValueTypesRepo
					.findByValueId(classificationClassifiedObj.getClassifiedByValueId());
			String typeOfAlert = classificationValueTypesObj.getName();
			valueIdAlertTypeMap.put(classificationClassifiedObj.getValueId(), typeOfAlert);
		}
		// for each classificationValuesList, get name of alert
		// form final Result
		AlertObject alertObject = new AlertObject();
		for (ClassificationValues classificationValuesObj : classificationValuesList) {
			ClassificationValueTypes classificationValueTypesObj = classificationValueTypesRepo
					.findByValueId(classificationValuesObj.getValueId());
			String nameOfAlert = classificationValueTypesObj.getName();
			AlertObjectInner alertObjectInner = new AlertObjectInner();
			alertObjectInner.setName(nameOfAlert);
			alertObjectInner.setUrl("/productdirectory/productclassification/classificationvalue/"
					+ classificationValueTypesObj.getValueId());
			alertObjectInner.setAlertType(valueIdAlertTypeMap.get(classificationValueTypesObj.getValueId()));
			alertObject.add(alertObjectInner);
		}
		AlertsResponseWrapper alertsResponseWrapper = new AlertsResponseWrapper();
		alertsResponseWrapper.setResponse(alertObject);

		return alertsResponseWrapper;
	}

	public AlertsResponseWrapper reliable(AlertsP pojo) {
		// TODO
		return new AlertsResponseWrapper();
	}

	@Override
	public <T> T error(int statusCode, Class<T> type, Exception exception)
			throws InstantiationException, IllegalAccessException {
		// TODO to write error response
		return type.newInstance();
	}
}