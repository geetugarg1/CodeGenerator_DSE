package com.api.dse.alerts.poc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.api.dse.alerts.poc.model.ClassificationValueTypes;
import com.api.dse.alerts.poc.model.ClassificationValues;

@Repository
public class ClassificationValuesRepo {

	public ClassificationValuesRepo() {
		// TODO Auto-generated constructor stub
	}
	
	 @Autowired
	 JdbcTemplate template;
	 
	 public List<ClassificationValues> findByCustId(Long custId, Long schemaId) {

		    return template.query("select * from tableOfClassificationValues where custId = ? AND valueId in(select valueId from  tableOfClassificationClassified where classifiedByValueId in (select valueId from tableOfClassificationValueTypes where schemaId=?) );", new Object[] {

		    		custId,
		    		schemaId

		        },

		        new BeanPropertyRowMapper < ClassificationValues > (ClassificationValues.class));

		}


}
