package com.api.dse.alerts.poc.model;

public class Schemas {

	private Long schemaId;

	private String name;

	private String description;

	private String source;

	public Schemas() {
	}

	public Schemas(Long schemaId, String name, String description, String source) {
		this.schemaId = schemaId;
		this.name = name;
		this.description = description;
		this.source = source;
	}
	
	public Long getSchemaId() {
		return schemaId;
	}

	public void setSchemaId(Long schemaId) {
		this.schemaId = schemaId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}


}
