package com.api.dse.alerts.poc.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.api.dse.alerts.poc.model.ClassificationClassified;
import com.api.dse.alerts.poc.model.ClassificationValueTypes;

@Repository
public class ClassificationClassifiedRepo {

	public ClassificationClassifiedRepo() {
		// TODO Auto-generated constructor stub
	}
	
	 @Autowired
	 JdbcTemplate template;
	 
	 public List<ClassificationClassified> findBySchemaId(Long schemaId) {

		    return template.query("select * from  tableOfClassificationClassified where classifiedByValueId in (select valueId from tableOfClassificationValueTypes where schemaId=?)", new Object[] {

		    		schemaId

		        },

		        new BeanPropertyRowMapper < ClassificationClassified > (ClassificationClassified.class));

		}


}
