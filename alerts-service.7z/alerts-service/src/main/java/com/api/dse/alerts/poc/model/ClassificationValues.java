package com.api.dse.alerts.poc.model;

public class ClassificationValues {

	private Long custId;
	private String valueId;

	public ClassificationValues() {
	}

	public ClassificationValues(Long custId, String valueId) {
		this.custId = custId;
		this.valueId = valueId;
	}

	public Long getCustId() {
		return custId;
	}

	public void setCustId(Long custId) {
		this.custId = custId;
	}

	public String getValueId() {
		return valueId;
	}

	public void setValueId(String valueId) {
		this.valueId = valueId;
	}

}
