package com.api.dse.alerts.poc.services.impl;

import java.util.*;

import static org.junit.Assert.*;
import org.junit.*;

public class AlertsImplTest{

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
	@Before
	public void setUp() throws Exception {
	}
	@After
	public void tearDown() throws Exception {
	}
	@Test
	public void testExecute() {
	//TODO
	}
}